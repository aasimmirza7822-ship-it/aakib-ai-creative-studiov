package com.aakib.commandcenter

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.aakib.shared.AgentCatalog
import com.aakib.shared.SkillCatalog
import java.util.Locale

data class DraftTask(val title: String, val detail: String, val state: String = "Waiting for your approval")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CommandCenterScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommandCenterScreen() {
    var command by remember { mutableStateOf("") }
    var selectedTab by remember { mutableStateOf("Overview") }
    var tasks by remember { mutableStateOf(listOf<DraftTask>()) }
    var search by remember { mutableStateOf("") }
    val speechLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) command = spoken
    }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold(
            topBar = {
                TopAppBar(title = { Text("AAKIB AI COMMAND CENTER") })
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("One Voice • 110 Specialist Agents", style = MaterialTheme.typography.titleMedium)
                Text("Voice language: Hinglish  |  Mode: Approval required")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Overview", "Agents", "Approvals", "Skills").forEach { tab ->
                        FilterChip(selected = selectedTab == tab, onClick = { selectedTab = tab }, label = { Text(tab) })
                    }
                }
                when (selectedTab) {
                    "Overview" -> {
                        Card {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Give your team a command", style = MaterialTheme.typography.titleLarge)
                                OutlinedTextField(command, { command = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Hinglish voice ya text command") })
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = {
                                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                                            putExtra(RecognizerIntent.EXTRA_PROMPT, "Apna command boliye")
                                        }
                                        try { speechLauncher.launch(intent) } catch (_: Exception) { }
                                    }) { Text("🎙 Speak") }
                                    Button(onClick = {
                                        if (command.isNotBlank()) {
                                            tasks = tasks + DraftTask("New team task", command.trim())
                                            command = ""
                                            selectedTab = "Approvals"
                                        }
                                    }, enabled = command.isNotBlank()) { Text("Create draft") }
                                }
                            }
                        }
                        Card {
                            Column(Modifier.padding(16.dp)) {
                                Text("Team status", style = MaterialTheme.typography.titleMedium)
                                Text("110 agent profiles • ${SkillCatalog.all.size} reusable skills")
                                Text("External publishing and DM connectors: not connected in this starter.")
                            }
                        }
                        Card {
                            Column(Modifier.padding(16.dp)) {
                                Text("Safety lock", style = MaterialTheme.typography.titleMedium)
                                Text("Instagram scope reserved for ${com.aakib.shared.ApprovalPolicy.INSTAGRAM_HANDLE}. Every publish/DM action must show a preview and receive your explicit approval.")
                            }
                        }
                    }
                    "Agents" -> {
                        OutlinedTextField(search, { search = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Search agents") })
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(AgentCatalog.all.filter { it.name.contains(search, true) || it.team.contains(search, true) }) { agent ->
                                Card { Column(Modifier.padding(12.dp)) {
                                    Text("${agent.id} • ${agent.name}", style = MaterialTheme.typography.titleSmall)
                                    Text(agent.team)
                                    Text(agent.description, style = MaterialTheme.typography.bodySmall)
                                } }
                            }
                        }
                    }
                    "Approvals" -> {
                        if (tasks.isEmpty()) Text("Abhi koi pending approval nahi hai. Pehle ek command create karein.")
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(tasks) { task ->
                                Card { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(task.title, style = MaterialTheme.typography.titleMedium)
                                    Text(task.detail)
                                    Text(task.state)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(onClick = { tasks = tasks.map { if (it == task) it.copy(state = "Approved by you — connector execution still needs setup") else it } }) { Text("Approve draft") }
                                        OutlinedButton(onClick = { tasks = tasks.map { if (it == task) it.copy(state = "Rejected") else it } }) { Text("Reject") }
                                    }
                                } }
                            }
                        }
                    }
                    "Skills" -> LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(SkillCatalog.all) { skill ->
                            Card { Column(Modifier.padding(12.dp)) {
                                Text(skill.name, style = MaterialTheme.typography.titleSmall)
                                Text(skill.purpose)
                            } }
                        }
                    }
                }
            }
        }
    }
}
