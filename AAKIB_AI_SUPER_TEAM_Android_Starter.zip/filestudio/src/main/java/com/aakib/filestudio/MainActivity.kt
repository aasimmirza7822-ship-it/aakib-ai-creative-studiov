package com.aakib.filestudio

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FileStudioScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileStudioScreen() {
    val context = LocalContext.current
    var files by remember { mutableStateOf(listOf<Uri>()) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { picked ->
        picked.forEach { uri ->
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) { }
        }
        files = (files + picked).distinct()
    }
    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold(topBar = { TopAppBar(title = { Text("AAKIB AI FILE STUDIO") }) }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Your creative project library", style = MaterialTheme.typography.titleLarge)
                Text("Manage selected videos, posters, scripts and project assets on this device.")
                Button(onClick = { picker.launch(arrayOf("image/*", "video/*", "application/pdf", "text/*")) }) {
                    Text("＋ Add files from phone")
                }
                Card {
                    Column(Modifier.padding(16.dp)) {
                        Text("Workspace folders", style = MaterialTheme.typography.titleMedium)
                        Text("01 • Reels & Videos")
                        Text("02 • Posters & Thumbnails")
                        Text("03 • Voiceovers & Audio")
                        Text("04 • Scripts & Captions")
                        Text("05 • Exports & Final Files")
                    }
                }
                Text("Selected files (${files.size})", style = MaterialTheme.typography.titleMedium)
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(files) { uri ->
                        Card { Column(Modifier.padding(12.dp)) {
                            Text(uri.lastPathSegment ?: uri.toString())
                            Text(uri.toString(), style = MaterialTheme.typography.bodySmall)
                            TextButton(onClick = {
                                val mime = context.contentResolver.getType(uri) ?: "application/octet-stream"
                                val send = Intent(Intent.ACTION_SEND).apply {
                                    type = mime
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(Intent.createChooser(send, "Share file"))
                            }) { Text("Share / export") }
                        } }
                    }
                }
                Text("Note: This first version is a local file workspace. AI generation, timeline editing and cloud sync need service integrations.")
            }
        }
    }
}

