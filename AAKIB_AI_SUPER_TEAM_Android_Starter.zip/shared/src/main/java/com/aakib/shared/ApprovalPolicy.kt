package com.aakib.shared

/**
 * All external side effects must pass through this policy.
 * The starter intentionally does not publish, send DMs, or modify remote accounts.
 */
object ApprovalPolicy {
    const val REQUIRE_EXPLICIT_APPROVAL = true
    const val ALLOWED_INSTAGRAM_ACCOUNT_ID = "17841433509064472"
    const val INSTAGRAM_HANDLE = "@aakib_creativeworks"

    fun mayExecute(status: ApprovalStatus): Boolean =
        status == ApprovalStatus.APPROVED
}

enum class ApprovalStatus { DRAFT, WAITING_FOR_APPROVAL, APPROVED, REJECTED, EXECUTED }
