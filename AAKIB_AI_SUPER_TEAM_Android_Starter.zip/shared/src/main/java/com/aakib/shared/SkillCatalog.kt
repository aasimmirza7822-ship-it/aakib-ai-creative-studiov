package com.aakib.shared

data class AgentSkill(val name: String, val purpose: String)

object SkillCatalog {
    val all = listOf(
        AgentSkill("Voice intent parsing", "Turn Hinglish voice requests into structured tasks."),
        AgentSkill("Task decomposition", "Split a goal into ordered specialist subtasks."),
        AgentSkill("Brand voice", "Keep copy consistent with the AAKIB CreativeWorks brand."),
        AgentSkill("Hook writing", "Draft strong opening hooks for short-form video."),
        AgentSkill("Short-form scripting", "Create concise Reel scripts with scene beats."),
        AgentSkill("Storyboard planning", "Convert scripts into visual shot lists."),
        AgentSkill("Caption writing", "Draft platform-ready captions."),
        AgentSkill("Hashtag research", "Prepare relevant hashtag candidates for review."),
        AgentSkill("Thumbnail direction", "Prepare cover concepts and readable title hierarchy."),
        AgentSkill("Video quality review", "Check pacing, clarity, aspect ratio, and audio notes."),
        AgentSkill("Audio quality review", "Flag clipping, noise, and uneven loudness."),
        AgentSkill("Copyright screening", "Flag assets or music that need rights verification."),
        AgentSkill("Content calendar", "Organize drafts and proposed publishing slots."),
        AgentSkill("File organization", "Tag and group assets by project and output type."),
        AgentSkill("Approval workflow", "Require a human decision before external actions."),
        AgentSkill("Privacy protection", "Keep secrets out of source code and logs."),
        AgentSkill("Instagram account scoping", "Restrict future integration to the approved account."),
        AgentSkill("Performance reporting", "Summarize verified post metrics when connected.")
    )
}
