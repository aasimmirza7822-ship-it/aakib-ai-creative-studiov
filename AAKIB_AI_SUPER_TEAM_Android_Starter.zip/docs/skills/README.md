# Skill packs

The shared module currently includes a small skill catalogue. Expand each skill as a versioned `SKILL.md` procedure with:
- a single purpose,
- when to load it,
- inputs and outputs,
- tool permissions,
- verification checklist,
- failure and escalation rules.

Do not grant every skill every tool. Apply least-privilege access per agent role.
