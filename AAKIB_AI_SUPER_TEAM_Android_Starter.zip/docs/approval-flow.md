# Approval flow contract

1. Agent produces a proposed action and immutable preview payload.
2. Backend stores the draft and computes a payload hash.
3. Command Center displays the exact content, media preview, target account, caption and action type.
4. User explicitly approves or rejects that exact payload.
5. Approval is single-use, expires, and is bound to the payload hash and account ID.
6. Any edit invalidates the approval and requires a new approval.
7. Publish/DM connector checks account allow-list and token scopes server-side.
8. Execution result and platform response are written to an audit log.

Never treat voice recognition alone as approval. Voice may create drafts; approval should require a distinct confirmation action.
