# AAKIB AI SUPER TEAM — Android Starter

This is a **source-code starter**, not a finished APK or a fully connected autonomous AI service.

## Two separate Android apps in one Android Studio project

- `:commandcenter` → AAKIB AI COMMAND CENTER
- `:filestudio` → AAKIB AI FILE STUDIO
- `:shared` → shared 110-agent directory, reusable skills and approval policy

## Current starter features

### Command Center
- Hinglish speech input using Android's speech recognizer (`hi-IN`).
- Text command input.
- 110 named specialist agent profiles across 11 departments.
- Searchable agent directory.
- Skills catalogue.
- Draft approval queue with Approve / Reject UI.
- Approval policy constants scoped to `@aakib_creativeworks` / Instagram account ID `17841433509064472`.

### File Studio
- Android system file picker for images, videos, PDFs and text files.
- Selected-file workspace list.
- Starter folder structure for reels, posters, audio, scripts and exports.

## Important: what is not connected yet

- No LLM / agent orchestration API is configured.
- No video generation or non-linear video editor is included yet.
- No ElevenLabs voice API is configured.
- No Instagram publishing, comment or DM API is connected.
- No cloud storage or account sign-in is configured.
- Approving a draft in this starter records the approval state in the UI; it does not publish anything.

Do not put API keys, access tokens, Instagram passwords or service secrets in the Android app. Use a backend service and store secrets server-side.

## Open in Android Studio

1. Install a recent Android Studio version with Android SDK 36.
2. Extract this ZIP.
3. Android Studio → Open → select this folder.
4. Allow Gradle sync to complete.
5. Build each app separately:
   - `:commandcenter:assembleDebug`
   - `:filestudio:assembleDebug`

The generated debug APKs will be under each module's `build/outputs/apk/debug/` folder.

## Suggested production architecture

- Android client: Kotlin + Jetpack Compose.
- Backend: authenticated API + job queue + durable task state.
- Orchestrator: manager agent delegates to specialist agents; do not start 110 independent model calls for every request.
- Skills: versioned, narrowly scoped procedures loaded only when needed.
- Media pipeline: upload → transcode/render → quality checks → preview.
- Approval gate: every external side effect requires a fresh, explicit user approval tied to the exact preview/action payload.
- Instagram integration: allow-list only account ID `17841433509064472`; require official Meta permissions and token handling on the backend.
- Audit log: record who approved what, when, and which payload was sent.

## Recommended next implementation milestones

1. Add backend sign-in and secure task persistence.
2. Connect an LLM provider and implement the manager/orchestrator loop.
3. Implement real approval records and signed, one-time execution tokens.
4. Add ElevenLabs voice generation (only after API credentials are configured server-side).
5. Add media rendering/export pipeline for 9:16 MP4.
6. Add official Instagram Graph API integration, with preview and explicit approval before publishing.
7. Add cloud file storage and job progress notifications.
8. Build, test on a physical Android phone, and sign release APKs.
